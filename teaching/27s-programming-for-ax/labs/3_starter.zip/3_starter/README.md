# Inspection report starter

## 먼저 할 일

이 폴더를 AI 코딩 도구에서 열고 이 README, inspection.csv, checks.py를 문맥에 붙이세요. Python 문법을 직접 작성하는 과제가 아닙니다. AI에 아래 계약을 전달해 실행 가능한 파일을 받고 결과를 열어 확인합니다.

## 입력과 현재 규칙

- 입력은 inspection.csv의 8행입니다. 원본 행과 순서를 모두 보존합니다.
- score가 비면 missing입니다. 숫자가 아니거나 유한하지 않거나 [0,1] 밖이면 invalid입니다.
- valid score가 0.50 이상일 때 flagged=true입니다. 나머지 valid score는 false입니다.
- missing과 invalid의 flagged는 JSON null입니다. score를 0으로 채우지 않습니다.
- 반복 ID는 경고 목록에 한 번 넣고 해당 원본 행들은 모두 보존합니다.

## AI에 보낼 요청

Read README.md, inspection.csv and checks.py. Create app.py using only the Python standard library. Generate report.json and inspection-report.html with every raw row in order. Do not modify inspection.csv or checks.py. Do not install packages or upload data. Run the generator and checker, and return the artifact paths and actual command output.

## 실행

터미널에서 동작하는 Python3 명령을 확인하고 아래 python을 그 명령으로 바꾸세요.

```text
python app.py --input inspection.csv --output report.json --html inspection-report.html
python checks.py
```

## JSON 계약

최상위 key는 summary, duplicate_ids, rows입니다.

summary는 raw, valid, flagged, missing, invalid 정수 key를 갖습니다. duplicate_ids는 정렬된 중복 ID 목록입니다. rows는 원본 순서의 8개 object이며 row(1부터의 행 번호), id, raw_score(원본 문자열), status(valid/missing/invalid), flagged(true/false/null)를 갖습니다.

이 입력의 독립 기준은 raw=8, valid=6, flagged=4, missing=1, invalid=1이며 duplicate_ids는 ["A06"]입니다. 이 값에 맞추려고 CSV나 checker를 바꾸지 마세요. app.py는 CSV를 읽고 계산해야 합니다.

## HTML 계약

제목과 다섯 요약 수, 8행의 원본 순서 table을 포함합니다. id, raw score, status, flagged를 읽을 수 있어야 하며 두 A06 행을 모두 표시합니다. 외부 script·library는 쓰지 않습니다. 브라우저에서 직접 열어 확인합니다.

## 실제 AI 경로의 완료물

- app.py, report.json, inspection-report.html
- 첫 요청과 후속 수정 요청 한 개
- 실제 실행한 명령과 checker 출력
- 변경 diff 또는 checkpoint·복원 기록

실행하지 않았다면 성공했다고 쓰지 않습니다. 도구 접근이 없으면 수업 notebook의 ‘대체 경로’를 사용하고 그 사실을 기록합니다.

## 확장과 복원

첫 통과 뒤 작업 상태를 Git 또는 IDE checkpoint로 보존하세요. HTML 제목을 Inspection Review로 바꾸는 작은 확장을 AI에 요청합니다. JSON과 원본 행은 유지하며 다시 생성·검사합니다. 최신 app.py 변경만 복원한 뒤 보고서를 다시 생성해 결과를 확인합니다.
