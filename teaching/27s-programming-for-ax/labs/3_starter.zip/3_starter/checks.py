"""Independent fixture checks. Do not modify this file to accept a candidate."""
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
import csv,json,math,sys

def expected(csv_path):
    with open(csv_path,newline="",encoding="utf-8")as f:raw=list(csv.DictReader(f))
    rows=[]
    for i,r in enumerate(raw,1):
        value=r["score"].strip()
        try:
            score=float(value)
            status="valid"if math.isfinite(score)and 0<=score<=1 else "invalid"
        except ValueError:status="missing"if not value else "invalid"
        rows.append({"row":i,"id":r["id"],"raw_score":r["score"],"status":status,
                     "flagged":score>=.5 if status=="valid"else None})
    summary={"raw":len(rows),"valid":sum(r["status"]=="valid"for r in rows),
             "flagged":sum(r["flagged"]is True for r in rows),
             "missing":sum(r["status"]=="missing"for r in rows),
             "invalid":sum(r["status"]=="invalid"for r in rows)}
    duplicates=sorted(k for k,v in Counter(r["id"]for r in rows).items()if v>1)
    return {"summary":summary,"duplicate_ids":duplicates,"rows":rows}

class Page(HTMLParser):
    def __init__(self):super().__init__();self.text=[];self.rows=0
    def handle_starttag(self,tag,attrs):
        if tag=="tr":self.rows+=1
    def handle_data(self,data):self.text.append(data)

def check(folder):
    folder=Path(folder);want=expected(folder/"inspection.csv")
    actual=json.loads((folder/"report.json").read_text(encoding="utf-8"))
    assert actual==want,"report.json differs from the source-derived row and summary contract"
    page=Page();page.feed((folder/"inspection-report.html").read_text(encoding="utf-8"))
    text=" ".join(page.text)
    assert page.rows>=9,"HTML must contain a header and all eight data rows"
    assert text.count("A06")>=2,"HTML must preserve both A06 rows"
    for label in ["A04","A05","missing","invalid"]:assert label in text,f"HTML lacks {label}"
    for value in ["8","6","4","1"]:assert value in text,f"HTML summary lacks {value}"
    return want["summary"]

if __name__=="__main__":
    try:
        result=check(Path(sys.argv[1])if len(sys.argv)>1 else Path(__file__).resolve().parent)
    except (AssertionError,OSError,ValueError,KeyError)as error:
        print("CHECK FAILED:",error);sys.exit(1)
    print("CHECK PASSED:",json.dumps(result,sort_keys=True))
